# References and Resources

## Books and Publications

Allen, D. (2001). _Getting things done: The art of stress-free productivity_. Penguin.

Alter, A. (2017). _Irresistible: The rise of addictive technology and the business of keeping us hooked_. Penguin Press.

Aron, E. N. (1996). _The highly sensitive person: How to thrive when the world overwhelms you_. Broadway Books.

Bailey, C. (2018). _Hyperfocus: How to be more productive in a world of distraction_. Viking.

Barkley, R. A. (2015). _Attention-deficit hyperactivity disorder: A handbook for diagnosis and treatment_ (4th ed.). Guilford Press.

Brewer, J. (2021). _Unwinding anxiety: New science shows how to break the cycles of worry and fear to heal your mind_. Avery.

Breus, M. (2016). _The power of when: Discover your chronotype_. Little, Brown Spark.

Brown, B. (2012). _Daring greatly: How the courage to be vulnerable transforms the way we live, love, parent, and lead_. Gotham Books.

Burns, D. (1980). _Feeling good: The new mood therapy_. William Morrow.

Cameron, J. (2002). _The artist’s way_. Penguin.

Clear, J. (2018). _Atomic habits: An easy & proven way to build good habits & break bad ones_. Avery.

Cloud, H. (1992). _Boundaries: When to say yes, how to say no to take control of your life_. Zondervan.

Crawford, M. B. (2015). _The world beyond your head: On becoming an individual in an age of distraction_. Farrar, Straus and Giroux.

Cuddy, A. (2015). _Presence: Bringing your boldest self to your biggest challenges_. Little, Brown and Company.

Davidson, R. J., & Begley, S. (2012). _The emotional life of your brain: How its unique patterns affect the way you think, feel, and live—and how you can change them_. Hudson Street Press.

Duhigg, C. (2012). _The power of habit: Why we do what we do in life and business_. Random House.

Dweck, C. (2006). _Mindset: The new psychology of success_. Random House.

Eyal, N. (2014). _Hooked: How to build habit-forming products_. Portfolio.

Ferriss, T. (2007). _The 4-hour workweek: Escape 9-5, live anywhere, and join the new rich_. Crown Publishing.

Forte, T. (2022). _Building a second brain: A proven method to organize your digital life and unlock your creative potential_. Atria Books.

Fredrickson, B. (2009). _Positivity: Top-notch research reveals the upward spiral that will change your life_. Crown.

Freeman, J. K. (2015). _The creator’s code: Six essential skills of extraordinary entrepreneurs_. Simon & Schuster.

Freeman, J. K. (2019). _Life without the internet: A beginner’s guide to unplugging and connection_. Self-published.

Gazzaley, A., & Rosen, L. (2016). _The distracted mind: Ancient brains in a high-tech world_. MIT Press.

Goldstein, J. (2013). _Mindfulness: A practical guide to awakening_. Sounds True.

Goleman, D. (1995). _Emotional intelligence: Why it can matter more than IQ_. Bantam Books.

Grant, A. (2014). _Give and take: Why helping others drives our success_. Penguin Books.

Hanson, R. (2013). _Hardwiring happiness: The new brain science of contentment, calm, and confidence_. Harmony.

Harari, Y. N. (2018). _21 lessons for the 21st century_. Spiegel & Grau.

Harris, R. (2008). _The happiness trap: How to stop struggling and start living_. Shambhala.

Hayes, S. C., Strosahl, K. D., & Wilson, K. G. (2012). _Acceptance and commitment therapy: The process and practice of mindful change_ (2nd ed.). Guilford Press.

Hochschild, A. R. (1983). _The managed heart: Commercialization of human feeling_. University of California Press.

Hyatt, M. (2019). _Free to focus: A total productivity system to achieve more by doing less_. Baker Books.

James, W. (1890). _The principles of psychology_. Henry Holt and Company.

Kahneman, D. (2011). _Thinking, fast and slow_. Farrar, Straus and Giroux.

Knapp, J. (2018). _Make time: How to focus on what matters every day_. Currency.

Lanier, J. (2018). _Ten arguments for deleting your social media accounts right now_. Henry Holt and Co.

Loehr, J., & Schwartz, T. (2003). _The power of full engagement: Managing energy, not time, is the key to high performance and personal renewal_. Free Press.

McGonigal, K. (2011). _The willpower instinct: How self-control works, why it matters, and what you can do to get more of it_. Avery.

Neff, K. (2011). _Self-compassion: The proven power of being kind to yourself_. William Morrow.

Newport, C. (2016). _Deep work: Rules for focused success in a distracted world_. Grand Central Publishing.

Newport, C. (2019). _Digital minimalism: Choosing a focused life in a noisy world_. Portfolio.

Nolen-Hoeksema, S. (2004). _Women who think too much: How to break free of overthinking and reclaim your life_. Holt Paperbacks.

Pang, A. S. (2016). _Rest: Why you get more done when you work less_. Basic Books.

Pennebaker, J. W. (1997). _Opening up: The healing power of expressing emotions_. Guilford Press.

Pink, D. H. (2009). _Drive: The surprising truth about what motivates us_. Riverhead Books.

Price, C. (2018). _How to break up with your phone_. Ten Speed Press.

Roenneberg, T. (2012). _Internal time: Chronotypes, social jet lag, and why you’re so tired_. Harvard University Press.

Rosen, L. (2012). _iDisorder: Understanding our obsession with technology and overcoming its hold on us_. Palgrave Macmillan.

Sawyer, K. (2013). _Zig zag: The surprising path to greater creativity_. Jossey-Bass.

Schwartz, B. (2004). _The paradox of choice: Why more is less_. Harper Perennial.

Schwartz, R. (1995). _Internal family systems therapy_. Guilford Press.

Tawwab, N. G. (2021). _Set boundaries, find peace: A guide to reclaiming yourself_. TarcherPerigee.

Thaler, R. H., & Sunstein, C. R. (2009). _Nudge: Improving decisions about health, wealth, and happiness_. Penguin Books.

Turkle, S. (2011). _Alone together: Why we expect more from technology and less from each other_. Basic Books.

Walker, M. (2017). _Why we sleep: Unlocking the power of sleep and dreams_. Scribner.

Williams, J. (2018). _Stand out of our light: Freedom and resistance in the attention economy_. Cambridge University Press.

Wilson, T. (2004). _Strangers to ourselves: Discovering the adaptive unconscious_. Belknap Press.

Young, V. (2011). _The secret thoughts of successful women: Why capable people suffer from the impostor syndrome and how to thrive in spite of it_. Crown Business.

Zack, D. (2015). _Singletasking: Get more done—one thing at a time_. Berrett-Koehler Publishers.

## Research Studies and Scientific Findings

Arnsten, A. F. T. (2009). Stress signalling pathways that impair prefrontal cortex structure and function. _Nature Reviews Neuroscience, 10_(6), 410-422.

Bailenson, J. N. (2021). Nonverbal overload: A theoretical argument for the causes of Zoom fatigue. _Technology, Mind, and Behavior, 2_(1).

Bandura, A. (2001). Social cognitive theory: An agentic perspective. _Annual Review of Psychology, 52_, 1-26.

Barnes, C. M., Lucianetti, L., Bhave, D. P., & Christian, M. S. (2015). “You wouldn’t like me when I’m sleepy”: Leaders’ sleep, daily abusive supervision, and work unit engagement. _Academy of Management Journal, 58_(5), 1419-1437.

Baumeister, R. F., Bratslavsky, E., Muraven, M., & Tice, D. M. (1998). Ego depletion: Is the active self a limited resource? _Journal of Personality and Social Psychology, 74_(5), 1252-1265.

Brewer, J. A., Worhunsky, P. D., Gray, J. R., Tang, Y. Y., Weber, J., & Kober, H. (2011). Meditation experience is associated with differences in default mode network activity and connectivity. _Proceedings of the National Academy of Sciences, 108_(50), 20254-20259.

Cross, R., Rebele, R., & Grant, A. (2016). Collaborative overload. _Harvard Business Review, 94_(1), 74-79.

Davidson, R. J., Kabat-Zinn, J., Schumacher, J., Rosenkranz, M., Muller, D., Santorelli, S. F., Urbanowski, F., Harrington, A., Bonus, K., & Sheridan, J. F. (2003). Alterations in brain and immune function produced by mindfulness meditation. _Psychosomatic Medicine, 65_(4), 564-570.

Dunbar, R. I. M. (1992). Neocortex size as a constraint on group size in primates. _Journal of Human Evolution, 22_(6), 469-493.

Farb, N. A. S., Segal, Z. V., Mayberg, H., Bean, J., McKeon, D., Fatima, Z., & Anderson, A. K. (2007). Attending to the present: Mindfulness meditation reveals distinct neural modes of self-reference. _Social Cognitive and Affective Neuroscience, 2_(4), 313-322.

Fredrickson, B. L. (2001). The role of positive emotions in positive psychology: The broaden-and-build theory of positive emotions. _American Psychologist, 56_(3), 218-226.

Killingsworth, M. A., & Gilbert, D. T. (2010). A wandering mind is an unhappy mind. _Science, 330_(6006), 932.

Kross, E., Verduyn, P., Demiralp, E., Park, J., Lee, D. S., Lin, N., Shablack, H., Jonides, J., & Ybarra, O. (2013). Facebook use predicts declines in subjective well-being in young adults. _PLoS ONE, 8_(8), e69841.

Leroy, S. (2009). Why is it so hard to do my work? The challenge of attention residue when switching between work tasks. _Organizational Behavior and Human Decision Processes, 109_(2), 168-181.

Mark, G., Gudith, D., & Klocke, U. (2008). The cost of interrupted work: More speed and stress. _Proceedings of the SIGCHI Conference on Human Factors in Computing Systems_, 107-110.

Miller, G. A. (1956). The magical number seven, plus or minus two: Some limits on our capacity for processing information. _Psychological Review, 63_(2), 81-97.

Neff, K. D. (2003). Self-compassion: An alternative conceptualization of a healthy attitude toward oneself. _Self and Identity, 2_(2), 85-101.

Nolen-Hoeksema, S. (2000). The role of rumination in depressive disorders and mixed anxiety/depressive symptoms. _Journal of Abnormal Psychology, 109_(3), 504-511.

Ophir, E., Nass, C., & Wagner, A. D. (2009). Cognitive control in media multitaskers. _Proceedings of the National Academy of Sciences, 106_(37), 15583-15587.

Pennebaker, J. W., & Beall, S. K. (1986). Confronting a traumatic event: Toward an understanding of inhibition and disease. _Journal of Abnormal Psychology, 95_(3), 274-281.

Perlow, L. A. (2012). _Sleeping with your smartphone: How to break the 24/7 habit and change the way you work_. Harvard Business Review Press.

Posner, M. I., & Petersen, S. E. (1990). The attention system of the human brain. _Annual Review of Neuroscience, 13_, 25-42.

Przybylski, A. K., Murayama, K., DeHaan, C. R., & Gladwell, V. (2013). Motivational, emotional, and behavioral correlates of fear of missing out. _Computers in Human Behavior, 29_(4), 1841-1848.

Raichle, M. E., MacLeod, A. M., Snyder, A. Z., Powers, W. J., Gusnard, D. A., & Shulman, G. L. (2001). A default mode of brain function. _Proceedings of the National Academy of Sciences, 98_(2), 676-682.

Schultz, W. (2016). Dopamine reward prediction error coding. _Dialogues in Clinical Neuroscience, 18_(1), 23-32.

Tang, Y. Y., Hölzel, B. K., & Posner, M. I. (2015). The neuroscience of mindfulness meditation. _Nature Reviews Neuroscience, 16_(4), 213-225.

Ward, A. F., Duke, K., Gneezy, A., & Bos, M. W. (2017). Brain drain: The mere presence of one’s own smartphone reduces available cognitive capacity. _Journal of the Association for Consumer Research, 2_(2), 140-154.

## Digital Tools for Attention Management

### Focus Environment

*   Freedom (https://freedom.to)
*   Forest (https://www.forestapp.cc)
*   Brain.fm (https://brain.fm)
*   myNoise (https://mynoise.net)
*   Serene (https://sereneapp.com)

### Mindfulness Supports

*   Headspace (https://www.headspace.com)
*   Waking Up (https://wakingup.com)
*   Oak (https://www.oakmeditation.com)
*   Insight Timer (https://insighttimer.com)
*   Calm (https://www.calm.com)

### Digital Minimalism

*   Siempo (https://www.getsiempo.com)
*   Opal (https://www.opal.so)
*   Minimalist Phone Launcher (https://blloc.com)
*   Digital Wellbeing (https://wellbeing.google)
*   Screen Time (https://support.apple.com/en-us/HT208982)

### Creation-First Tools

*   Obsidian (https://obsidian.md)
*   Notion (https://www.notion.so)
*   Drafts (https://getdrafts.com)
*   Ulysses (https://ulysses.app)
*   Roam Research (https://roamresearch.com)

### Attention Analytics

*   RescueTime (https://www.rescuetime.com)
*   Toggl (https://toggl.com)
*   Focus App (https://heyfocus.com)
*   Moment (https://inthemoment.io)
*   Timely (https://timelyapp.com)

## Key Concepts and Terminology

Attention residue: The mental carryover that occurs when switching tasks, where thoughts about the previous task persist and interfere with the new task.

Continuous partial attention: The state of perpetually dividing attention among multiple sources of input and stimuli.

Default mode network (DMN): Neural network active during mind-wandering, self-reflection, and creative thought.

Deep work: The ability to focus without distraction on a cognitively demanding task.

Digital minimalism: A philosophy that applies a minimalist mindset to digital tool use.

Emotional hijacking: When the amygdala overrides the prefrontal cortex during stress or emotional arousal.

Executive control network: Brain system responsible for directing attention, maintaining focus, and inhibiting distractions.

Inattentional blindness: Failure to notice an unexpected stimulus that is in one’s field of vision when other attention-demanding tasks are being performed.

Mental time travel: Cognitive process of shifting attention between past events, future possibilities, and present experience.

Open loops: Incomplete tasks or unresolved matters that occupy mental resources.

System 1 and System 2 thinking: Fast, automatic thinking (System 1) versus slow, deliberate thinking (System 2) as conceptualized by Daniel Kahneman.

Task-unrelated thoughts (TUTs): Thoughts that are unrelated to the current activity or goal.

Ultradian rhythms: Natural cycles of energy and focus that typically operate in 90-120 minute intervals.

Variable reward schedule: Unpredictable pattern of rewards that creates powerful reinforcement and habit formation.

Working memory: Limited capacity system for temporarily holding and manipulating information.

## Case Studies

_Note: All case studies have been anonymized and represent composite profiles based on real experiences._

*   Alex: Management consultant struggling with rumination and digital overload
*   Carlos: Writer transforming relationship with self-criticism
*   David: Architect implementing comprehensive smartphone simplification
*   Elena: Novelist using journaling for performance anxiety
*   Emily: College student experiencing hybrid physical-digital distraction
*   James: Attorney implementing digital delay for legal writing
*   Jason: Marketing professional with compulsive social media checking
*   Laura: Consultant balancing deep work with responsiveness expectations
*   Marcus: Project manager implementing email optimization
*   Maria: Curriculum designer establishing morning creation ritual
*   Maya: Graphic designer with severe inner critic
*   Michael: Software developer discovering optimal work patterns
*   Miguel: Product designer improving creation through preparation
*   Mike: Data analyst with interrupting colleague
*   Rachel: Teacher experiencing rumination after difficult conversations
*   Rebecca: Marketing director mapping her dual creative peaks
*   Robert: Management consultant overcoming email-first habit
*   Sarah: Marketing executive creating environmental supports
*   Teresa: Teacher restructuring content consumption
*   Thomas: Sales representative distracted by real-time metrics

