# Chapter 3: The External Offenders

Have you ever noticed how even a brief power outage creates an unsettling silence? The refrigerator’s hum, the faint buzz of electronics, the distant traffic—all suddenly gone. In those moments, many people experience a strange mix of discomfort and relief—like finally noticing a persistent ringing in your ears only when it stops.

This is the reality of modern existence: we’re immersed in a sea of external noise so constant that we’ve normalized it. We’ve adapted to an environment saturated with stimuli that our ancestors would find overwhelming, perhaps even maddening.

Now that we understand the anatomy of noise and the neuroscience of attention, it’s time to identify the specific external offenders—the sources of noise that most aggressively compete for your finite attentional resources. By naming and understanding these external forces, you take the first step toward reclaiming your sovereignty over them.

## The Digital Cacophony

The most obvious and pervasive source of external noise in modern life comes through our screens. The digital realm has evolved from a tool we occasionally use to an environment we perpetually inhabit.

### Social Media: Addiction by Design

Social media platforms represent perhaps the most sophisticated attention-capture systems ever created. Their impact on our attentional lives operates through multiple mechanisms:

#### The Infinite Scroll

Traditional media had natural endpoints—you finished the newspaper, the TV show ended, the magazine ran out of pages. Social media eliminated these stopping cues through the infinite scroll, a design feature that continuously loads new content as you approach the bottom of your feed.

This seemingly simple interface choice exploits what behavioral scientists call “momentum behavior”—the tendency to continue an activity once started until we encounter a clear reason to stop. When that stopping point is removed, usage time dramatically increases.

A former Facebook executive described it bluntly: “The infinite scroll is not an accident. It’s engineered to keep you consuming as long as possible.”

#### The Variable Reward Schedule

What makes checking social media so compelling isn’t just the content itself but the unpredictability of the reward. Sometimes you’ll find something fascinating, sometimes something validating, sometimes nothing interesting at all—but the possibility of reward keeps you checking.

This pattern of reinforcement—known as a variable reward schedule—is the same mechanism that makes gambling so addictive. As discussed in the previous chapter, it creates a powerful dopamine response that overrides rational decision-making.

Nir Eyal, author of “Hooked: How to Build Habit-Forming Products,” explains how this works: “Variable rewards are one of the most powerful tools companies implement to hook users. Research shows that levels of the neurotransmitter dopamine surge when the brain is expecting a reward. Introducing variability multiplies the effect, creating a focused state where attention is fixated on the stimulus and motivation to take action is heightened.”

#### The Social Validation Feedback Loop

Perhaps most powerful is how these platforms leverage our deep human need for social connection and validation. Every like, share, and comment activates reward circuits in our brains that evolved to keep us connected to our tribes—because historically, social connection was literally a matter of survival.

Sean Parker, Facebook’s founding president, later admitted: “It’s a social validation feedback loop… exactly the kind of thing that a hacker like myself would come up with, because you’re exploiting a vulnerability in human psychology.”

The metrics of followers, likes, and engagement become proxies for social worth, creating what psychologists call “contingent self-esteem”—where your sense of value becomes dependent on external validation. This psychological dependency ensures users return repeatedly to platforms that may actually diminish their overall wellbeing.

Dr. Rachel Goldman, a clinical psychologist specializing in social media’s effects on mental health, notes: “Many of my clients describe a love-hate relationship with social media. They recognize how it increases their anxiety and feeds negative self-comparison, yet they feel unable to disconnect because their sense of social connection and, increasingly, their professional identity is tied to these platforms.”

#### The Cost of Connection

While social media offers genuine benefits—connection across distances, community for isolated individuals, voice for marginalized groups—the aggregate impact on our attentional lives is largely negative:

*   The average American checks social media 17 times daily, with younger users averaging 30+ daily checks
*   Social media users touch their phones an average of 2,617 times daily
*   86% of smartphone users check their devices while conversing with friends and family
*   72% report feeling anxiety when separated from their phones

Jason, a marketing professional I interviewed, described his relationship with social media: “I joined Twitter initially for work—to stay current in my industry. Now I find myself checking it first thing in the morning, while waiting in any line, during meetings, before bed… I’m constantly dipping in and out of this stream of content that’s mostly useless to me. But the fear of missing something important keeps me tethered to it.”

### The News Cycle: Crisis as Content

If social media hijacks our attention through its form, news media often captures it through intensity of content—particularly content that triggers threat-detection mechanisms in our brains.

#### The Perpetual Emergency

News organizations have always understood that alarming or negative news captures attention more effectively than positive news—“if it bleeds, it leads” was a journalistic truism long before digital media. This reflects our brain’s negativity bias, an evolutionary adaptation that makes us more sensitive to potential threats than to rewards.

What’s changed is the pace and pervasiveness of this content. The 24-hour news cycle, coupled with algorithm-driven feeds that amplify emotionally activating content, creates a perpetual sense of emergency—a constant stream of crises demanding our attention.

Dr. Graham Davey, who studies the psychological effects of news consumption, explains: “The way that news is presented and the way that we access news has changed significantly over the last 15 to 20 years. These changes have often been detrimental to general mental health.”

His research shows that negative news consumption triggers the body’s stress response, increasing anxiety and mood deterioration. Yet the same mechanisms that make news stressful also make it attention-grabbing and difficult to ignore.

#### Crisis Fatigue

This constant exposure to crisis information creates what mental health professionals call “crisis fatigue”—a state of emotional exhaustion resulting from chronic activation of our threat-response systems.

Crisis fatigue manifests as a paradoxical mix of anxiety and numbness. We remain vigilant to potential threats but become desensitized to their emotional impact. Each new crisis prompts us to check for updates while feeling increasingly helpless to respond meaningfully.

Teresa, a teacher I interviewed, described her experience: “During the pandemic, I developed a compulsive news-checking habit. I’d refresh sites dozens of times daily, absorbing every new statistic and development. Even though it made me anxious, I couldn’t stop. Now, years later, I still have this habit of constantly checking headlines, but I feel less and less each time. It’s like I need to know what’s happening but can’t fully process it anymore.”

This pattern creates a particularly destructive attentional drain—consuming significant mental bandwidth while diminishing our capacity to respond thoughtfully to the information we’re consuming.

### Communication Overload: The Always-On Expectation

Beyond social media and news, our devices host an ever-expanding array of communication tools—email, messaging apps, video conferencing platforms—each with its own implicit expectations of availability and response time.

#### The Email Avalanche

Despite predictions of its demise, email remains a primary source of communication noise for most professionals. The average office worker receives 121 emails daily and spends 28% of their workweek managing email.

What makes email particularly disruptive isn’t just the volume but the context-switching it requires. Each message potentially represents a different project, relationship, or task—demanding your brain repeatedly reorient itself as you process your inbox.

The three-fold increase in email volume over the past decade hasn’t been accompanied by an equivalent increase in our cognitive capacity to process it. This mismatch creates what information researchers call “email bankruptcy”—the point at which the backlog becomes unmanageable, leading to missed messages, delayed responses, and chronic anxiety about what might be buried in your inbox.

#### The Messaging Multiplication

While email grew linearly, messaging apps have multiplied exponentially. Many professionals now juggle multiple platforms—Slack for work teams, WhatsApp for personal connections, Teams for certain collaborations, Discord for communities, and standard text messaging for everything else.

Each platform creates its own attentional debt through:

*   **Notification fragmentation**: Different alert sounds, badges, and vibration patterns force your brain to constantly categorize and prioritize incoming stimuli
*   **Context dispersion**: Related conversations split across multiple platforms require you to maintain separate mental models for each communication space
*   **Platform-specific expectations**: Each platform develops its own implicit norms about appropriate response times and availability

Lucas, a software developer, described how this fragmentation affects his workday: “I’m in seven Slack workspaces, plus Teams for clients, plus email, plus texts. Every platform has its own emergency—someone always needs something ‘urgent.’ I’ve started silencing everything, but then I worry about missing something truly important. There’s no winning.”

#### The Zoom Fatigue Phenomenon

Video conferencing, which became ubiquitous during the pandemic, introduces its own unique form of attentional taxation. Researchers at Stanford have identified four mechanisms behind what they term “Zoom fatigue”:

1.  **Excessive eye contact**: Video calls create unnatural amounts of direct eye contact
2.  **Constant self-view**: Seeing yourself constantly during interactions is taxing
3.  **Reduced mobility**: Being fixed in one position for extended periods
4.  **Increased cognitive load**: Working harder to send and receive nonverbal cues

These factors combine to make video meetings significantly more attentionally demanding than in-person interactions, despite seeming superficially similar. A one-hour video call requires more sustained attention than an equivalent in-person meeting, leaving many people feeling inexplicably drained after a day of virtual interactions.

Dr. Jeremy Bailenson, founding director of Stanford’s Virtual Human Interaction Lab, explains: “Zoom fatigue is a distinct form of exhaustion that follows video conferencing. It’s not just tiredness—it’s a response to specific cognitive and attentional demands that these platforms create.”

## The Environmental Battleground

While digital noise dominates modern attention discussions, physical environments continue to play a crucial role in either supporting or sabotaging our capacity for focus.

### The Open Office Catastrophe

The open office concept—originally designed to foster collaboration and reduce real estate costs—has become one of the most significant environmental sources of attentional disruption in modern work.

Studies consistently show that open office plans reduce productivity, with workers in open offices experiencing:

*   70% more sick days
*   50% higher levels of stress
*   40% more cognitive errors
*   65% more difficulty focusing on tasks

The primary mechanism behind these effects is auditory distraction. Background conversations are particularly disruptive because they activate the language-processing regions of our brain, essentially forcing us to unconsciously process others’ words even when we’re trying to focus on our own task.

Dr. Sally Augustin, an environmental psychologist, explains: “Our brains are designed to process human speech—we can’t simply ‘tune it out’ the way we might with white noise or mechanical sounds. Each time you hear a snippet of conversation, your brain automatically begins processing its meaning, disrupting whatever task you were focused on.”

This creates what researchers call the “irrelevant speech effect”—where performance on cognitive tasks decreases significantly when exposed to background speech, even if you’re not consciously listening to it.

Maria, a graphic designer, described her experience: “I do creative work that requires deep concentration, but our office has no walls, no barriers. I can hear every sales call, every customer service interaction, every casual conversation. I’ve tried noise-canceling headphones, but they only help so much. By the end of each day, I feel like my brain has been put through a blender.”

### Digital-Physical Overlap: When Worlds Collide

Increasingly, our physical and digital environments bleed into each other, creating hybrid spaces where attention is subjected to both physical and virtual disruptions simultaneously.

Consider a typical coffee shop scene: People sit together physically while mentally inhabiting separate digital spheres. A constant stream of notifications punctuate ambient conversations, while screens display motion and color changes that capture attention from across the room.

This overlap creates what attention researchers call “environmental competition”—where physical and digital stimuli compete for our limited attentional resources, often leading to a state where we’re never fully present in either realm.

Emily, a college student, described this phenomenon: “I’ll be studying in the library, and even with headphones, I’m distracted by movements in my peripheral vision—people walking by, screens flickering. Then my own phone lights up, and even if I don’t check it, my train of thought is broken. I’m not fully in my physical space or my digital space—I’m caught between worlds.”

### Sensory Overload: The Stimulation Surplus

Beyond specific environments like offices or coffee shops, modern life generally provides far more sensory stimulation than our attentional systems evolved to handle.

Urban environments bombard us with stimuli—traffic noise, advertisements, crowds, architectural complexity, artificial lighting. Each element requires some amount of processing, creating what neuroscientists call “perceptual load”—the total amount of sensory information your brain must process.

When perceptual load exceeds our capacity, several things happen:

*   Attention becomes diffuse and difficult to sustain
*   Stress hormones increase
*   Cognitive performance decreases
*   Emotional regulation becomes more difficult

Dr. Michael Posner, a pioneer in attention research, notes: “The human attentional system evolved in environments with natural stopping points and significantly less sensory density. Modern environments, particularly urban and digital ones, present perceptual challenges that tax our neural architecture in ways we’re still coming to understand.”

This helps explain why activities in nature or minimalist environments often feel restorative—they reduce perceptual load to levels our brains can process without strain.

## The Human Element: Interpersonal Noise

Perhaps the most complex source of external noise comes from other people—our interactions, relationships, and social dynamics that can either support or sabotage our attentional integrity.

### The Attention Hijackers

Some interactions consistently drain cognitive resources through predictable patterns:

#### The Energy Vampire

These individuals leave you feeling depleted after interactions—typically through negativity, drama, or excessive demands for emotional labor. The hallmark of an energy vampire is that time with them requires more recovery time than the interaction itself.

Research in emotional contagion shows that negative emotions transfer more readily between people than positive ones. This means that brief exposure to someone’s constant complaints or catastrophizing can affect your emotional state—and by extension, your attentional capacity—for hours afterward.

#### The Interrupter

Chronic interrupters break your focus repeatedly, often with matters that could easily wait for a more appropriate time. Each interruption triggers the complete attentional reorientation cycle discussed in Chapter 2, with its associated switching costs.

Studies show that even brief interruptions of 2-3 seconds double error rates on sequential tasks and increase completion time by 40%. When these interruptions come from colleagues or family members who could choose more appropriate timing, they represent a particularly preventable source of cognitive taxation.

Mike, a data analyst, described his experience with an interrupting colleague: “He’ll walk up to my desk multiple times daily with questions he could easily email or save for our weekly check-in. Each time, it takes me about 20 minutes to get back into the flow of what I was doing. I’ve tracked it, and on days he’s out of office, I get nearly twice as much done.”

#### The Boundary Violator

Some relationships create attentional drain through consistent boundary violations—expecting immediate responses regardless of your other commitments, making excessive demands on your time, or invading spaces you’ve designated for focus.

Psychologists note that poor boundaries often stem from what they call “emotional fusion”—where others believe their needs should automatically take priority over your focus or well-being.

Dr. Nedra Glover Tawwab, a boundaries expert, explains: “Healthy boundaries aren’t just about saying no—they’re about creating the conditions where your attention can be allocated according to your values and needs rather than others’ demands.”

### The Cultural Expectations

Beyond individual relationships, broader cultural expectations create significant interpersonal noise:

#### The “Always On” Professional Expectation

In many industries, being perceived as immediately responsive has become equated with being committed, hardworking, or reliable. This creates pressure to remain perpetually available regardless of the cost to deep work or recovery time.

A Harvard Business School study found that professionals who took longer to respond to emails were rated as less committed and less effective by colleagues—regardless of their actual work output or quality. This perception creates what researchers call “impression management pressure,” where workers feel compelled to demonstrate responsiveness at the expense of focused work.

Laura, a consultant, described this pressure: “I produce better work when I block out 3-4 hour periods of uninterrupted focus. But the expectation in my firm is that you respond to emails within 30 minutes. So I’m constantly toggling between deep work and superficial responsiveness, doing neither particularly well.”

#### The Multitasking Myth as Cultural Value

Despite overwhelming evidence that multitasking impairs performance, many organizational cultures continue to valorize it—explicitly or implicitly rewarding those who appear to handle multiple streams of information simultaneously.

This cultural myth creates pressure to engage in behaviors we know are counterproductive. In one survey, 71% of professionals reported feeling they “should” be able to handle simultaneous inputs better, despite recognizing that focusing on one thing at a time produced better results.

### The Toxic Information Exchange

Some interpersonal noise manifests specifically through the content exchanged between people:

#### Unsolicited Opinions

The proliferation of comment sections, review platforms, and feedback mechanisms has created an environment where unsolicited opinions flow constantly. While feedback can be valuable, indiscriminate exposure to others’ perspectives—particularly those designed to provoke rather than contribute—creates significant attentional burden.

Research shows that negative feedback occupies disproportionate mental space compared to positive feedback. A single critical comment can outweigh multiple positive ones in its impact on your thought processes and emotional state.

#### The Rumor Mill

Workplace or social gossip creates a particularly insidious form of informational noise. Rumors activate both social threat monitoring systems (am I being excluded/judged?) and problem-solving processes (what should I do about this?), creating substantial cognitive load without actionable resolution.

Dr. Timothy Levine, who studies deception and truth-default theory, notes: “Rumors burden our cognitive systems with unverifiable information that triggers both analytical thinking and emotional processing. They’re attentional parasites—consuming resources while providing no useful output.”

### The Relationship Between External and Internal Noise

External interpersonal noise quickly transforms into internal noise through rumination, worry, and self-criticism. A brief uncomfortable interaction can generate hours of internal noise as your mind replays, analyzes, and catastrophizes about the exchange.

This transformation represents one of the most challenging aspects of managing attentional integrity—the way external triggers create disproportionate internal disruption long after the initial stimulus has ended.

Rachel, a teacher, described this effect: “A three-minute difficult conversation with a parent can occupy my thoughts for days. I’ll replay it, imagine alternative responses, worry about repercussions… all while trying to be present for my students. The actual interaction is brief, but the mental aftermath is enormous.”

## Institutional Noise: Systems That Steal Attention

Beyond individual relationships and technologies, the very systems and institutions we operate within often create structural conditions that fragment attention.

### The Meeting Madness

Meetings represent one of the most significant institutional drains on collective attention. Consider:

*   The average employee spends 31 hours monthly in unproductive meetings
*   73% of people do other work during meetings
*   Most meetings are called without clear objectives or necessary participants
*   Executives spend an average of 23 hours weekly in meetings

This creates what management researchers call “collaboration overload”—where excessive coordination activities prevent the focused work they’re supposedly coordinating.

Dr. Rob Cross, a professor of global leadership, found that time spent on collaboration has increased by more than 50% in the past decade, while time available for focused individual contribution has correspondingly decreased.

### The Bureaucratic Burden

Administrative processes—approval workflows, compliance requirements, documentation demands—create substantial attentional overhead in most organizations.

Research from Harvard Business Review found that managers spend 30-60% of their time on administrative coordination rather than value-creating activities. This administrative load cascades throughout organizations, creating what economists call “attention transaction costs”—the cognitive resources expended on coordination rather than contribution.

### The Metrics Mirage

Increasingly, organizations implement real-time performance metrics and dashboards that encourage constant monitoring and comparison. While measurement can drive improvement, continuous metrics create attentional pull that disrupts the very work being measured.

Dr. Cal Newport calls this “metric fixation”—where the measurement of work begins to take precedence over the work itself, creating a self-reinforcing cycle of shallow engagement.

Thomas, a sales representative, described how metrics affected his attention: “Our team dashboard updates in real-time, showing everyone’s numbers. I find myself checking it constantly, comparing my performance, feeling either relief or anxiety. I probably check it 30 times daily, and each time it breaks my focus on actually selling.”

## Media and Entertainment: The Passive Attention Drain

While much external noise involves active engagement, passive media consumption creates its own attentional challenges:

### Content Saturation

The explosion of streaming services, podcasts, and other media options has created unprecedented competition for our leisure attention. The average American now has access to more content than they could consume in several lifetimes, creating what psychologists call “choice overload”—where excessive options lead to decision fatigue and decreased satisfaction.

This abundance transforms even relaxation into a potentially depleting activity, as we constantly evaluate whether we’re choosing the “best” use of our limited leisure time.

### Algorithmic Recommendation Engines

Recommendation algorithms continuously suggest content based on your viewing history, creating potential “filter bubbles” that narrow your exposure while simultaneously encouraging extended consumption through auto-play features and “you might also like” suggestions.

These systems are explicitly designed to maximize watch time rather than satisfaction or value, often leading to what researchers call “regretted consumption”—where users later feel their time was not well spent despite being engaged in the moment.

A Netflix executive famously noted that their biggest competitor wasn’t other streaming services but sleep itself—revealing the attention-maximizing incentives that drive these platforms.

### Background Consumption

Many people now maintain continuous background media—music, podcasts, TV shows—while engaging in other activities. While some background stimulus can enhance performance on simple tasks, research shows it significantly impairs performance on complex cognitive work.

This “continuous partial attention” state has become normalized despite its documented negative effects on memory formation, comprehension, and creative thinking.

## Reflection: Mapping Your External Noise Landscape

As with previous chapters, understanding these external noise sources becomes useful only when you apply it to your specific situation. Consider these questions:

1.  **Digital Drain**: Which digital platforms consume the most of your attention? Of these, which provide genuine value versus habitual consumption?
2.  **Environmental Factors**: What aspects of your physical environments most frequently disrupt your focus? Which elements could be modified?
3.  **Relationship Audit**: Which relationships consistently support your attentional integrity, and which consistently undermine it?
4.  **Institutional Pressures**: What systemic expectations in your work or community create unnecessary attentional overhead?
5.  **Media Consumption**: How does your entertainment consumption affect your attentional capacity? Does it restore or deplete your resources?

## The Path Forward: From Identification to Action

Identifying these external offenders isn’t just an academic exercise—it’s the necessary first step toward reclaiming your attentional sovereignty. In the coming chapters, we’ll explore specific strategies for managing these external sources of noise.

Remember that the goal isn’t to eliminate all external stimulation—connection, information, and sensory richness are essential elements of a meaningful life. Rather, the aim is to create a more intentional relationship with these inputs—one where you choose what deserves your attention based on your values and goals rather than reacting to whatever shouts loudest.

By understanding the specific external forces competing for your attention, you’ve taken a crucial step toward freedom from their grip. The next chapters will equip you with practical tools to transform this awareness into action.

**Chapter Summary:**

*   Social media platforms use sophisticated design techniques like infinite scrolling, variable rewards, and social validation to capture attention
*   The 24-hour news cycle creates a state of perpetual emergency that taxes our threat-detection systems
*   Communication technologies generate overwhelming volume while creating expectations of constant availability
*   Physical environments like open offices create auditory and visual disruptions that fragment attention
*   Interpersonal relationships can either support or undermine attentional integrity through boundaries and expectations
*   Institutional systems often create structural conditions that make sustained attention difficult
*   Media and entertainment platforms are engineered to maximize watch time rather than value
*   Managing external noise begins with identifying specific offenders in your personal environment

