# Part I: Understanding the Noise

[PLACEHOLDER: PartI]

