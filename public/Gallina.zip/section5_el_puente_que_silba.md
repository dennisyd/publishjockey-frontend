# El puente que silba

El puente viejo silbaba cuando soplaba el cierzo. Decían que estaba encantado; Manolo decía que estaba mal construido. De todos modos, nunca lo cruzaba.

—¿Vienes, Manolo? —preguntó Lucía desde la otra orilla—. ¡La feria ya empezó!

Manolo miró la madera oscura, oyó el silbido y sintió el apodo pesándole en la espalda como una mochila llena de piedras.

—Voy por el camino largo… —murmuró.

Mientras bordeaba el río, encontró a Don Evaristo, el carpintero, sentado sobre un tronco.

—El puente no muerde, muchacho —dijo el viejo sin mirarlo—. Solo canta cuando el viento le recuerda que está vivo.

Manolo quiso sonreír, pero no pudo. Apretó los puños y siguió. Cuando llegó por fin a la feria, ya anochecía. Lucía le ofreció un trozo de turrón.

—Algún día —pensó Manolo— cruzaré ese puente cuando silbe más fuerte que mis miedos.

Esa noche, antes de dormir, el viento volvió a cantar. Y, por primera vez, Manolo escuchó una nota de reto.

