# El Grande Gallina

## Manzanas

Por Juan Carlos

Derechos de autor © 2025 por Juan Carlos. Todos los derechos reservados.

Ninguna parte de este libro puede ser reproducida en cualquier forma o por cualquier medio electrónico o mecánico, incluyendo sistemas de almacenamiento y recuperación de información, sin el permiso escrito del autor, excepto para el uso de citas breves en una reseña de libro.

