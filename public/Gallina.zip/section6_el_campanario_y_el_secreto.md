# El campanario y el secreto

A la mañana siguiente, el pueblo despertó con un rumor: la campana mayor no sonó. El sacristán andaba de viaje y nadie quería subir los ciento trece escalones. Nadie… salvo Lucía, que ya estaba en la puerta de la iglesia con las llaves en la mano.

—¿Vienes? —preguntó, alzando una ceja.

Manolo tragó saliva. El campanario era alto, estrecho y lleno de sombras que parecían respirar. Subieron. En el escalón treinta y ocho, Manolo se detuvo.

—No puedo —dijo—. Me tiemblan las piernas.

—Las piernas tiemblan; la decisión no —respondió Lucía—. Agárrate de la baranda y sube conmigo.

Escalón tras escalón, el corazón de Manolo golpeaba como un tambor. Cuando llegaron arriba, el viento entró por las ventanas y el pueblo quedó pequeño, como un dibujo.

La cuerda estaba enredada. Manolo la sostuvo; estaba áspera, real, no un fantasma. Respiró hondo, desenredó con cuidado y, sin pensarlo demasiado, tiró.

¡CLANG!

El sonido cruzó tejados, calles y gallineros. Manolo sonrió, sorprendido de su propia fuerza. Lucía le dio un leve empujón en el hombro.

—Mira —dijo señalando al horizonte—. El puente viejo… escucha cómo silba.

El viento trajo el mismo canto de la tarde anterior. Pero esta vez, Manolo no oyó un puente que asusta; oyó un amigo que llama.

—Esta tarde —dijo—. Esta tarde lo cruzo.

Y, por primera vez desde que le pusieron el apodo, El Grande Gallina sintió que el nombre empezaba a quedarle grande por otra razón.
