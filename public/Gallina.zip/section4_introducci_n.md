# Introducción

En el pueblo de San Jacinto todos conocían a El Grande Gallina. No era un gallo ni una gallina; era Manolo, un chico alto, con pasos silenciosos y un corazón que latía demasiado rápido cuando alguien decía: «¿Te atreves?». Le pusieron el apodo porque siempre encontraba una excusa para no cruzar el puente viejo, para no hablar en público, para no subir al campanario. Pero una tarde de viento —de esos vientos que levantan hojas, secretos y valor— algo cambió.

